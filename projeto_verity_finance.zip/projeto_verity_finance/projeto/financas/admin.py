from django.contrib import admin
from financas.models import Usuario, Despesa, Data, Perfil, Grafico, Saldo, Banco, Objetivo, Data

# Register your models here.
admin.site.register(Usuario)
admin.site.register(Despesa)
admin.site.register(Perfil)
admin.site.register(Grafico)
admin.site.register(Saldo)
admin.site.register(Banco)
admin.site.register(Objetivo)
admin.site.register(Data)
