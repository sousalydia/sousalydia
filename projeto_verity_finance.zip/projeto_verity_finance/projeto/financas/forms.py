from django import forms
from .models import Usuario
from .models import Saldo

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['Nome', 'Email', 'Senha']

class SaldoForm(forms.ModelForm):
    class Meta:
        model = Saldo
        fields = ['Valor', 'Rendimento']