from django.db import models

# Create your models here.

class Usuario(models.Model):
    Nome = models.CharField(max_length=45)
    Email = models.CharField(max_length=45)
    Senha = models.CharField(max_length=45)

class Despesa(models.Model):
    Custo = models.IntegerField()
    Descricao = models.CharField(max_length=45)
    Tipo = models.CharField(max_length=45)
    Tipo_de_despesa = models.CharField(max_length=50)
    Forma_de_pagamento = models.CharField(max_length=50)
    
class Data(models.Model):
    Data = models.DateField()
    Despesa = models.ForeignKey(Despesa, on_delete=models.CASCADE)

class Objetivo(models.Model):
    Rendimento = models.IntegerField()
    Valor = models.IntegerField()
    Tempo_Restante = models.DateTimeField()
    Valor_Poupado = models.IntegerField()
    Porcentagem_do_salario = models.IntegerField()
    Tipo_de_objetivo = models.CharField(max_length=45)
    Data = models.DateField()
    Dinheiro_Falta = models.IntegerField()

class Saldo(models.Model):
    Valor = models.IntegerField()
    Rendimento = models.IntegerField()

class Grafico(models.Model):
    Tipo = models.CharField(max_length=45)
    Tema = models.CharField(max_length=45)
    Despesa = models.ForeignKey(Despesa, on_delete=models.CASCADE)
    Valor = models.ForeignKey(Saldo, on_delete=models.CASCADE)

class Banco(models.Model):
    Banco = models.CharField(max_length=45)
    Saldo = models.ForeignKey(Saldo, on_delete=models.CASCADE)
    Instuicao_bancaria = models.CharField(max_length=45)

class Perfil(models.Model):
    Nome = models.CharField(max_length=45)
    Email = models.CharField(max_length=45)
    Senha = models.CharField(max_length=45)
    Sexo = models.CharField(max_length=45)
    Usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    Sonhos = models.ForeignKey(Objetivo, on_delete=models.CASCADE)
    Despesas = models.ForeignKey(Despesa, on_delete=models.CASCADE)
    Saldo = models.ForeignKey(Saldo, on_delete=models.CASCADE)




