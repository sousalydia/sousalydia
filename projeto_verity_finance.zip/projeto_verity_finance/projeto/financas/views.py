from django.shortcuts import render, redirect
from .models import Usuario
from .models import Saldo
from .forms import UsuarioForm, SaldoForm

# Create your views here.
def list_usuario(request):
    usuario = Usuario.objects.all()
    return render(request, 'usuario/listagem.html', {'chave':usuario})

def novo_usuario(request):
    form = UsuarioForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('url_list_usuario')
        
    return render(request,'usuario/form.html',{'form':form})

def update_usuario(request, pk):
    usuario = Usuario.objects.get(pk=pk)
    form = UsuarioForm(request.POST or None, instance=usuario)

    if form.is_valid():
        form.save()
        return redirect('url_list_usuario')
        
    return render(request,'usuario/update.html',{'form':form, 'usuario': usuario})

def delete_usuario(request, pk):
    usuario = Usuario.objects.get(pk=pk)
    usuario.delete()
    return redirect('url_list_usuario')

def list_saldo(request):
    saldo = Saldo.objects.all()
    return render(request, 'saldo/listagem.html', {'chave':saldo})

def novo_saldo(request):
    form = SaldoForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('url_list_saldo')
        
    return render(request,'saldo/form.html',{'form':form})

def update_saldo(request, pk):
    saldo = Saldo.objects.get(pk=pk)
    form = SaldoForm(request.POST or None, instance=saldo)

    if form.is_valid():
        form.save()
        return redirect('url_list_saldo')
        
    return render(request,'saldo/update.html',{'form':form, 'saldo': saldo})

def delete_saldo(request, pk):
    saldo = Saldo.objects.get(pk=pk)
    saldo.delete()
    return redirect('url_list_saldo')