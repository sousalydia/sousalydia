"""projeto URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from financas.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', list_usuario, name='url_list_usuario'),
    path('usuario/novo/', novo_usuario, name='url_novo_usuario'),
    path('usuario/update/<int:pk>/', update_usuario, name='url_update_usuario'),
    path('usuario/delete/<int:pk>/', delete_usuario, name='url_delete_usuario'),
    path('saldos/', list_saldo, name='url_list_saldo'),
    path('saldo/novo/', novo_saldo, name='url_novo_saldo'),
    path('saldo/update/<int:pk>/', update_saldo, name='url_update_saldo'),
    path('saldo/delete/<int:pk>/', delete_saldo, name='url_delete_saldo'),
]
